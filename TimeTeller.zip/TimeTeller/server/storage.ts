import { type Watch, type InsertWatch, type CartItem, type InsertCartItem, type Newsletter, type InsertNewsletter } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Watch operations
  getWatches(): Promise<Watch[]>;
  getWatch(id: string): Promise<Watch | undefined>;
  getWatchesByCategory(category: string): Promise<Watch[]>;
  getWatchesByBrand(brand: string): Promise<Watch[]>;
  searchWatches(query: string): Promise<Watch[]>;
  createWatch(watch: InsertWatch): Promise<Watch>;
  
  // Cart operations
  getCartItems(sessionId: string): Promise<(CartItem & { watch: Watch })[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: string): Promise<boolean>;
  clearCart(sessionId: string): Promise<void>;
  
  // Newsletter operations
  subscribeNewsletter(newsletter: InsertNewsletter): Promise<Newsletter>;
}

export class MemStorage implements IStorage {
  private watches: Map<string, Watch>;
  private cartItems: Map<string, CartItem>;
  private newsletters: Map<string, Newsletter>;

  constructor() {
    this.watches = new Map();
    this.cartItems = new Map();
    this.newsletters = new Map();
    this.initializeWatches();
  }

  private initializeWatches() {
    const initialWatches: InsertWatch[] = [
      {
        name: "Heritage Chronograph",
        brand: "Swiss Movement Collection",
        collection: "Heritage",
        price: "2499.00",
        image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        description: "A masterpiece of Swiss engineering featuring a sophisticated chronograph movement with premium leather strap.",
        category: "chronograph",
        isNew: true,
        movement: "Swiss Automatic",
        caseMaterial: "Stainless Steel",
        dialColor: "Black",
        strapMaterial: "Genuine Leather",
        waterResistance: "100m",
        caseSize: "42mm"
      },
      {
        name: "Modern Minimalist",
        brand: "Contemporary Series",
        collection: "Modern",
        price: "1899.00",
        image: "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        description: "Clean lines and modern aesthetics define this contemporary timepiece with precision quartz movement.",
        category: "dress",
        movement: "Swiss Quartz",
        caseMaterial: "Titanium",
        dialColor: "White",
        strapMaterial: "Metal Bracelet",
        waterResistance: "50m",
        caseSize: "40mm"
      },
      {
        name: "Vintage Classic",
        brand: "Heritage Collection",
        collection: "Vintage",
        price: "2799.00",
        originalPrice: "3299.00",
        image: "https://images.unsplash.com/photo-1533139502658-0198f920d8e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        description: "Inspired by vintage timepieces with Roman numerals and classic styling meets modern reliability.",
        category: "vintage",
        isOnSale: true,
        movement: "Swiss Automatic",
        caseMaterial: "Rose Gold",
        dialColor: "Cream",
        strapMaterial: "Alligator Leather",
        waterResistance: "30m",
        caseSize: "38mm"
      },
      {
        name: "Sport Chronograph",
        brand: "Professional Series",
        collection: "Sport",
        price: "3599.00",
        image: "https://images.unsplash.com/photo-1547996160-81dfa63595aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        description: "Built for performance with professional chronograph functions and robust construction for active lifestyles.",
        category: "sport",
        movement: "Swiss Automatic Chronograph",
        caseMaterial: "Ceramic",
        dialColor: "Blue",
        strapMaterial: "Rubber",
        waterResistance: "300m",
        caseSize: "44mm"
      },
      {
        name: "Dress Elegance",
        brand: "Formal Collection",
        collection: "Elegance",
        price: "4299.00",
        image: "https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        description: "Ultimate sophistication for formal occasions with ultra-thin profile and exquisite finishing.",
        category: "dress",
        movement: "Swiss Ultra-thin Automatic",
        caseMaterial: "18k Gold",
        dialColor: "Silver",
        strapMaterial: "Crocodile Leather",
        waterResistance: "30m",
        caseSize: "39mm"
      },
      {
        name: "Limited Edition",
        brand: "Exclusive Series",
        collection: "Limited",
        price: "8999.00",
        image: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        description: "Exclusive limited edition timepiece with intricate complications and handcrafted details.",
        category: "limited",
        isLimited: true,
        movement: "Swiss Manufacture Movement",
        caseMaterial: "Platinum",
        dialColor: "Black",
        strapMaterial: "Alligator Leather",
        waterResistance: "50m",
        caseSize: "41mm"
      }
    ];

    initialWatches.forEach(watch => {
      const id = randomUUID();
      this.watches.set(id, { ...watch, id });
    });
  }

  async getWatches(): Promise<Watch[]> {
    return Array.from(this.watches.values());
  }

  async getWatch(id: string): Promise<Watch | undefined> {
    return this.watches.get(id);
  }

  async getWatchesByCategory(category: string): Promise<Watch[]> {
    return Array.from(this.watches.values()).filter(watch => watch.category === category);
  }

  async getWatchesByBrand(brand: string): Promise<Watch[]> {
    return Array.from(this.watches.values()).filter(watch => 
      watch.brand.toLowerCase().includes(brand.toLowerCase())
    );
  }

  async searchWatches(query: string): Promise<Watch[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.watches.values()).filter(watch =>
      watch.name.toLowerCase().includes(searchTerm) ||
      watch.brand.toLowerCase().includes(searchTerm) ||
      watch.collection.toLowerCase().includes(searchTerm) ||
      watch.description.toLowerCase().includes(searchTerm)
    );
  }

  async createWatch(insertWatch: InsertWatch): Promise<Watch> {
    const id = randomUUID();
    const watch: Watch = { ...insertWatch, id };
    this.watches.set(id, watch);
    return watch;
  }

  async getCartItems(sessionId: string): Promise<(CartItem & { watch: Watch })[]> {
    const items = Array.from(this.cartItems.values())
      .filter(item => item.sessionId === sessionId);
    
    return items.map(item => {
      const watch = this.watches.get(item.watchId);
      if (!watch) throw new Error(`Watch not found: ${item.watchId}`);
      return { ...item, watch };
    });
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = Array.from(this.cartItems.values())
      .find(item => item.watchId === insertItem.watchId && item.sessionId === insertItem.sessionId);
    
    if (existingItem) {
      // Update quantity
      existingItem.quantity += insertItem.quantity;
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    }

    const id = randomUUID();
    const cartItem: CartItem = { ...insertItem, id };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;
    
    item.quantity = quantity;
    this.cartItems.set(id, item);
    return item;
  }

  async removeFromCart(id: string): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<void> {
    const itemsToRemove = Array.from(this.cartItems.entries())
      .filter(([, item]) => item.sessionId === sessionId)
      .map(([id]) => id);
    
    itemsToRemove.forEach(id => this.cartItems.delete(id));
  }

  async subscribeNewsletter(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    const id = randomUUID();
    const newsletter: Newsletter = { 
      ...insertNewsletter, 
      id, 
      subscribedAt: new Date().toISOString() 
    };
    this.newsletters.set(id, newsletter);
    return newsletter;
  }
}

export const storage = new MemStorage();
