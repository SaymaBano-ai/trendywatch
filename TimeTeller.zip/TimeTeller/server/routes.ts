import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCartItemSchema, insertNewsletterSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Watch routes
  app.get("/api/watches", async (req, res) => {
    try {
      const { category, brand, search } = req.query;
      
      let watches;
      if (search) {
        watches = await storage.searchWatches(search as string);
      } else if (category) {
        watches = await storage.getWatchesByCategory(category as string);
      } else if (brand) {
        watches = await storage.getWatchesByBrand(brand as string);
      } else {
        watches = await storage.getWatches();
      }
      
      res.json(watches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch watches" });
    }
  });

  app.get("/api/watches/:id", async (req, res) => {
    try {
      const watch = await storage.getWatch(req.params.id);
      if (!watch) {
        return res.status(404).json({ error: "Watch not found" });
      }
      res.json(watch);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch watch" });
    }
  });

  // Cart routes
  app.get("/api/cart", async (req, res) => {
    try {
      const sessionId = req.sessionID || "default-session";
      const cartItems = await storage.getCartItems(sessionId);
      res.json(cartItems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cart items" });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const sessionId = req.sessionID || "default-session";
      const validatedData = insertCartItemSchema.parse({
        ...req.body,
        sessionId
      });
      
      const cartItem = await storage.addToCart(validatedData);
      res.status(201).json(cartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid cart item data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add to cart" });
    }
  });

  app.put("/api/cart/:id", async (req, res) => {
    try {
      const { quantity } = req.body;
      if (typeof quantity !== 'number' || quantity < 1) {
        return res.status(400).json({ error: "Invalid quantity" });
      }
      
      const cartItem = await storage.updateCartItem(req.params.id, quantity);
      if (!cartItem) {
        return res.status(404).json({ error: "Cart item not found" });
      }
      
      res.json(cartItem);
    } catch (error) {
      res.status(500).json({ error: "Failed to update cart item" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      const success = await storage.removeFromCart(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Cart item not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove cart item" });
    }
  });

  app.delete("/api/cart", async (req, res) => {
    try {
      const sessionId = req.sessionID || "default-session";
      await storage.clearCart(sessionId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to clear cart" });
    }
  });

  // Newsletter route
  app.post("/api/newsletter", async (req, res) => {
    try {
      const validatedData = insertNewsletterSchema.parse(req.body);
      const newsletter = await storage.subscribeNewsletter(validatedData);
      res.status(201).json({ message: "Successfully subscribed to newsletter" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid email address", details: error.errors });
      }
      res.status(500).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  // IBM Watson Assistant proxy routes
  app.post("/api/watson/message", async (req, res) => {
    try {
      // This would integrate with IBM Watson Assistant
      // For now, return a simple response
      const { message } = req.body;
      
      // Simple keyword-based responses for demo
      let response = "I'm here to help you find the perfect watch. What are you looking for?";
      
      if (message.toLowerCase().includes("swiss")) {
        response = "Great choice! We have several Swiss watches in different price ranges. Would you prefer a chronograph, dress watch, or sports model?";
      } else if (message.toLowerCase().includes("price") || message.toLowerCase().includes("budget")) {
        response = "I can help you find watches in your budget. What's your price range? We have options from $1,500 to $10,000+.";
      } else if (message.toLowerCase().includes("rolex") || message.toLowerCase().includes("omega")) {
        response = "We carry authentic luxury brands. Let me show you some options from our premium collection.";
      }
      
      res.json({ response });
    } catch (error) {
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
