# Chronos Elite - Luxury Watch E-commerce Platform

## Overview

Chronos Elite is a sophisticated full-stack e-commerce application for luxury timepieces. The platform provides a premium shopping experience with features including product browsing, detailed watch specifications, shopping cart functionality, newsletter subscriptions, and an integrated chatbot for customer assistance. The application emphasizes elegant design with a luxury aesthetic, featuring a curated collection of high-end watches from prestigious brands.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The client-side application is built with **React 18** and **TypeScript**, utilizing modern React patterns including hooks and functional components. The architecture follows a component-based design with clear separation of concerns:

- **Routing**: Uses Wouter for lightweight client-side routing with support for parameterized routes
- **State Management**: Leverages React Query (TanStack Query) for server state management and caching, with local state handled through React hooks
- **UI Framework**: Implements Radix UI primitives with shadcn/ui components for consistent, accessible design
- **Styling**: Uses Tailwind CSS with custom CSS variables for theming, including luxury-specific color schemes

### Backend Architecture

The server is built with **Express.js** and follows RESTful API principles:

- **API Structure**: Organized route handlers in `/server/routes.ts` with clear endpoint definitions
- **Data Layer**: Implements a storage abstraction pattern with `IStorage` interface, currently using in-memory storage (`MemStorage`) with pre-seeded luxury watch data
- **Session Management**: Supports session-based cart functionality for guest users
- **Development Setup**: Integrated with Vite for hot module replacement and development experience

### Database Design

The application uses **Drizzle ORM** with PostgreSQL schema definitions:

- **Watches Table**: Comprehensive product catalog with detailed specifications (movement, materials, pricing)
- **Cart Items Table**: Session-based shopping cart with quantity tracking
- **Newsletter Table**: Email subscription management with timestamps
- **Schema Validation**: Zod integration for runtime type checking and data validation

### Authentication & Session Management

- **Session-based**: Uses session IDs for cart persistence without requiring user authentication
- **Guest Shopping**: Allows full shopping experience without account creation
- **Newsletter Subscriptions**: Independent email collection system

### External Dependencies

- **Neon Database**: PostgreSQL database hosting service
- **Drizzle Kit**: Database migrations and schema management
- **Watson Assistant**: AI-powered chatbot integration for customer support
- **Radix UI**: Accessible component primitives for consistent user interface
- **TanStack Query**: Server state management and caching layer
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Vite**: Build tool and development server with HMR support
- **TypeScript**: Type safety across the entire application stack

The application is designed for deployment on Replit with integrated development tools and follows modern web development best practices for performance, accessibility, and maintainability.