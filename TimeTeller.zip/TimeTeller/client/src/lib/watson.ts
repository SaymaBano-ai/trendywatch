interface WatsonMessage {
  message: string;
  sessionId?: string;
}

interface WatsonResponse {
  response: string;
}

export class WatsonService {
  private static instance: WatsonService;
  private sessionId: string;

  constructor() {
    this.sessionId = this.generateSessionId();
  }

  static getInstance(): WatsonService {
    if (!WatsonService.instance) {
      WatsonService.instance = new WatsonService();
    }
    return WatsonService.instance;
  }

  private generateSessionId(): string {
    return 'session_' + Math.random().toString(36).substring(2, 15);
  }

  async sendMessage(message: string): Promise<string> {
    try {
      const response = await fetch('/api/watson/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          sessionId: this.sessionId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send message to Watson');
      }

      const data: WatsonResponse = await response.json();
      return data.response;
    } catch (error) {
      console.error('Watson service error:', error);
      return "I'm sorry, I'm having trouble processing your request right now. Please try again later.";
    }
  }

  // Initialize IBM Watson Assistant Web Chat (if API keys are available)
  initializeWebChat() {
    const integrationId = import.meta.env.VITE_WATSON_INTEGRATION_ID;
    const region = import.meta.env.VITE_WATSON_REGION || 'us-south';
    const serviceInstanceId = import.meta.env.VITE_WATSON_SERVICE_INSTANCE_ID;

    if (integrationId && serviceInstanceId) {
      // @ts-ignore
      window.watsonAssistantChatOptions = {
        integrationID: integrationId,
        region: region,
        serviceInstanceID: serviceInstanceId,
        onLoad: function(instance: any) {
          instance.render();
        }
      };

      const script = document.createElement('script');
      script.src = "https://web-chat.global.assistant.watson.appdomain.cloud/versions/latest/WatsonAssistantChatEntry.js";
      document.head.appendChild(script);
    }
  }
}

export const watsonService = WatsonService.getInstance();
