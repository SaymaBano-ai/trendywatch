import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, ShoppingCart } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { type Watch } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function FeaturedProducts() {
  const { data: watches = [], isLoading } = useQuery<Watch[]>({
    queryKey: ["/api/watches"],
  });

  const { addToCart, isAddingToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = (watch: Watch) => {
    addToCart({ watchId: watch.id, quantity: 1 });
    toast({
      title: "Added to cart",
      description: `${watch.name} has been added to your cart.`,
    });
  };

  if (isLoading) {
    return (
      <section id="collections" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-rich-black mb-4">
              Featured Collections
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Each timepiece in our collection represents the pinnacle of horological excellence and design innovation.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-lg overflow-hidden animate-pulse">
                <div className="h-80 bg-gray-200"></div>
                <div className="p-6">
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="flex justify-between items-center">
                    <div className="h-8 bg-gray-200 rounded w-20"></div>
                    <div className="h-10 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="collections" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-rich-black mb-4">
            Featured Collections
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Each timepiece in our collection represents the pinnacle of horological excellence and design innovation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {watches.map((watch) => (
            <Card key={watch.id} className="bg-white rounded-lg shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-500">
              <div className="relative overflow-hidden">
                <Link href={`/product/${watch.id}`}>
                  <img 
                    src={watch.image} 
                    alt={watch.name}
                    className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500" 
                  />
                </Link>
                <div className="absolute top-4 left-4 flex gap-2">
                  {watch.isNew && (
                    <Badge className="bg-luxury-gold text-rich-black">NEW</Badge>
                  )}
                  {watch.isOnSale && (
                    <Badge className="bg-red-600 text-white">SALE</Badge>
                  )}
                  {watch.isLimited && (
                    <Badge className="bg-purple-600 text-white">LIMITED</Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-4 right-4 text-red-500 hover:text-red-600"
                >
                  <Heart className="h-5 w-5" />
                </Button>
              </div>
              
              <CardContent className="p-6">
                <Link href={`/product/${watch.id}`}>
                  <h3 className="text-xl font-semibold mb-2 hover:text-luxury-gold transition-colors">
                    {watch.name}
                  </h3>
                </Link>
                <p className="text-gray-600 mb-4">{watch.brand}</p>
                <div className="flex justify-between items-center">
                  <div className="flex flex-col">
                    {watch.originalPrice && (
                      <span className="text-lg text-gray-500 line-through">
                        ${parseFloat(watch.originalPrice).toLocaleString()}
                      </span>
                    )}
                    <span className="text-2xl font-bold text-luxury-gold">
                      ${parseFloat(watch.price).toLocaleString()}
                    </span>
                  </div>
                  <Button 
                    onClick={() => handleAddToCart(watch)}
                    disabled={isAddingToCart}
                    className="bg-rich-black text-white hover:bg-gray-800 transition-colors duration-300"
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
