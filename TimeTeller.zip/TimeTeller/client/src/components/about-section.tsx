export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-rich-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-playfair font-bold mb-6">
              Crafting Time Since 1985
            </h2>
            <p className="text-xl text-gray-300 mb-6 leading-relaxed">
              For over three decades, Chronos Elite has been the destination for discerning collectors and enthusiasts seeking exceptional timepieces that transcend mere functionality.
            </p>
            <p className="text-lg text-gray-400 mb-8 leading-relaxed">
              Our curated selection represents the finest in Swiss craftsmanship, innovative design, and horological excellence. Each watch tells a story of precision, artistry, and timeless elegance.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-luxury-gold mb-2">500+</div>
                <div className="text-sm text-gray-400">Premium Timepieces</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-luxury-gold mb-2">50+</div>
                <div className="text-sm text-gray-400">Luxury Brands</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-luxury-gold mb-2">15K+</div>
                <div className="text-sm text-gray-400">Satisfied Customers</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Expert watchmaker working on precision timepiece" 
              className="rounded-lg shadow-2xl w-full h-auto" 
            />
            <div className="absolute inset-0 bg-luxury-gold opacity-10 rounded-lg"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
