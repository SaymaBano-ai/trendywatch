import { useState } from "react";
import { Link } from "wouter";
import { Search, ShoppingCart, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";

interface HeaderProps {
  onSearchClick: () => void;
}

export default function Header({ onSearchClick }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { totalItems, setIsOpen: setCartOpen } = useCart();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0">
              <h1 className="text-2xl font-playfair font-bold text-rich-black">
                Chronos <span className="text-luxury-gold">Elite</span>
              </h1>
            </Link>
          </div>
          
          <nav className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a href="#collections" className="text-gray-700 hover:text-luxury-gold transition-colors duration-300">
                Collections
              </a>
              <a href="#new-arrivals" className="text-gray-700 hover:text-luxury-gold transition-colors duration-300">
                New Arrivals
              </a>
              <a href="#brands" className="text-gray-700 hover:text-luxury-gold transition-colors duration-300">
                Brands
              </a>
              <a href="#about" className="text-gray-700 hover:text-luxury-gold transition-colors duration-300">
                About
              </a>
              <a href="#contact" className="text-gray-700 hover:text-luxury-gold transition-colors duration-300">
                Contact
              </a>
            </div>
          </nav>

          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onSearchClick}
              className="text-gray-700 hover:text-luxury-gold transition-colors duration-300"
            >
              <Search className="h-5 w-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCartOpen(true)}
              className="text-gray-700 hover:text-luxury-gold transition-colors duration-300 relative"
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-luxury-gold text-rich-black text-xs rounded-full h-5 w-5 flex items-center justify-center font-semibold">
                  {totalItems}
                </span>
              )}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-gray-700 hover:text-luxury-gold transition-colors duration-300"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <a href="#collections" className="block px-3 py-2 text-gray-700 hover:text-luxury-gold">
              Collections
            </a>
            <a href="#new-arrivals" className="block px-3 py-2 text-gray-700 hover:text-luxury-gold">
              New Arrivals
            </a>
            <a href="#brands" className="block px-3 py-2 text-gray-700 hover:text-luxury-gold">
              Brands
            </a>
            <a href="#about" className="block px-3 py-2 text-gray-700 hover:text-luxury-gold">
              About
            </a>
            <a href="#contact" className="block px-3 py-2 text-gray-700 hover:text-luxury-gold">
              Contact
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
