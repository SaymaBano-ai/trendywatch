export default function BrandShowcase() {
  const brands = ['ROLEX', 'OMEGA', 'CARTIER', 'PATEK', 'BREITLING', 'TISSOT'];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-playfair font-bold text-rich-black mb-4">
            Trusted by Premium Brands
          </h2>
          <p className="text-lg text-gray-600">
            We partner with the world's most prestigious watchmakers
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center opacity-60">
          {brands.map((brand) => (
            <div key={brand} className="text-center">
              <div className="text-2xl font-playfair font-bold text-gray-700">
                {brand}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
