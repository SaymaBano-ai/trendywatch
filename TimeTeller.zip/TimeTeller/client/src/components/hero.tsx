import { Button } from "@/components/ui/button";

export default function Hero() {
  const scrollToCollections = () => {
    document.getElementById('collections')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-rich-black via-gray-900 to-rich-black opacity-60 z-10"></div>
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')"
        }}
      ></div>
      
      <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
        <h1 className="text-5xl md:text-7xl font-playfair font-bold mb-6 leading-tight">
          Timeless
          <span className="text-luxury-gold block">Elegance</span>
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-2xl mx-auto leading-relaxed">
          Discover our curated collection of premium timepieces that define sophistication and precision craftsmanship.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={scrollToCollections}
            className="bg-luxury-gold hover:bg-yellow-500 text-rich-black font-semibold py-4 px-8 transition-all duration-300 transform hover:scale-105"
          >
            EXPLORE COLLECTION
          </Button>
          <Button 
            variant="outline"
            onClick={scrollToCollections}
            className="border-2 border-white text-white hover:bg-white hover:text-rich-black font-semibold py-4 px-8 transition-all duration-300"
          >
            WATCH CATALOG
          </Button>
        </div>
      </div>
    </section>
  );
}
