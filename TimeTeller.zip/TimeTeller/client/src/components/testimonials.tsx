import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: "Michael Chen",
      location: "San Francisco, CA",
      review: "Exceptional service and an incredible selection. My Omega Speedmaster arrived perfectly packaged and exactly as described. Truly a premium experience.",
      rating: 5
    },
    {
      id: 2,
      name: "Sarah Williams",
      location: "New York, NY",
      review: "I've been collecting watches for 20 years, and Chronos Elite offers the best curation and customer service I've experienced. Highly recommended!",
      rating: 5
    },
    {
      id: 3,
      name: "David Rodriguez",
      location: "Miami, FL",
      review: "The authentication process and detailed documentation gave me complete confidence in my purchase. The watch exceeded my expectations in every way.",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-playfair font-bold text-rich-black mb-4">
            What Our Customers Say
          </h2>
          <p className="text-xl text-gray-600">
            Testimonials from satisfied collectors worldwide
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div className="flex text-luxury-gold">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-6 italic">
                  "{testimonial.review}"
                </p>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.location}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
