import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, X } from "lucide-react";
import { Link } from "wouter";
import { type Watch } from "@shared/schema";

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("");
  const [selectedPrice, setSelectedPrice] = useState("");

  const { data: searchResults = [], isLoading } = useQuery<Watch[]>({
    queryKey: ["/api/watches", { search: searchQuery, brand: selectedBrand }],
    enabled: searchQuery.length > 0 || selectedBrand.length > 0,
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const filteredResults = searchResults.filter((watch) => {
    if (selectedPrice) {
      const price = parseFloat(watch.price);
      switch (selectedPrice) {
        case "under-2000":
          return price < 2000;
        case "2000-5000":
          return price >= 2000 && price <= 5000;
        case "5000-10000":
          return price >= 5000 && price <= 10000;
        case "over-10000":
          return price > 10000;
        default:
          return true;
      }
    }
    return true;
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-2xl font-playfair font-bold">Search Watches</DialogTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </DialogHeader>

        <div className="space-y-6">
          <div className="relative">
            <Input
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search by brand, model, or collection..."
              className="pl-10"
            />
            <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select value={selectedBrand} onValueChange={setSelectedBrand}>
              <SelectTrigger>
                <SelectValue placeholder="All Brands" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Brands</SelectItem>
                <SelectItem value="Swiss Movement Collection">Swiss Movement</SelectItem>
                <SelectItem value="Contemporary Series">Contemporary</SelectItem>
                <SelectItem value="Heritage Collection">Heritage</SelectItem>
                <SelectItem value="Professional Series">Professional</SelectItem>
                <SelectItem value="Formal Collection">Formal</SelectItem>
                <SelectItem value="Exclusive Series">Exclusive</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedPrice} onValueChange={setSelectedPrice}>
              <SelectTrigger>
                <SelectValue placeholder="All Prices" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Prices</SelectItem>
                <SelectItem value="under-2000">Under $2,000</SelectItem>
                <SelectItem value="2000-5000">$2,000 - $5,000</SelectItem>
                <SelectItem value="5000-10000">$5,000 - $10,000</SelectItem>
                <SelectItem value="over-10000">Over $10,000</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-4">
            {isLoading ? (
              <p className="text-center text-gray-500 py-8">Searching...</p>
            ) : filteredResults.length > 0 ? (
              filteredResults.map((watch) => (
                <Link key={watch.id} href={`/product/${watch.id}`} onClick={onClose}>
                  <div className="flex items-center space-x-4 p-4 hover:bg-gray-50 rounded-lg cursor-pointer">
                    <img 
                      src={watch.image} 
                      alt={watch.name}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold">{watch.name}</h4>
                      <p className="text-sm text-gray-600">{watch.brand}</p>
                      <p className="text-lg font-bold text-luxury-gold">
                        ${parseFloat(watch.price).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </Link>
              ))
            ) : searchQuery || selectedBrand ? (
              <p className="text-center text-gray-500 py-8">No watches found matching your criteria.</p>
            ) : (
              <p className="text-center text-gray-500 py-8">Start typing to search our collection...</p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
