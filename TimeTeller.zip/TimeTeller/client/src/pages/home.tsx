import { useState } from "react";
import Header from "@/components/header";
import Hero from "@/components/hero";
import FeaturedProducts from "@/components/featured-products";
import BrandShowcase from "@/components/brand-showcase";
import AboutSection from "@/components/about-section";
import Testimonials from "@/components/testimonials";
import Newsletter from "@/components/newsletter";
import Footer from "@/components/footer";
import Chatbot from "@/components/chatbot";
import SearchModal from "@/components/search-modal";
import CartSidebar from "@/components/cart-sidebar";

export default function Home() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Header onSearchClick={() => setIsSearchOpen(true)} />
      <Hero />
      <FeaturedProducts />
      <BrandShowcase />
      <AboutSection />
      <Testimonials />
      <Newsletter />
      <Footer />
      <Chatbot />
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <CartSidebar />
    </div>
  );
}
