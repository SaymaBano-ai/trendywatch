import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Heart, ShoppingCart, Share2 } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import { type Watch } from "@shared/schema";
import Header from "@/components/header";
import Footer from "@/components/footer";
import CartSidebar from "@/components/cart-sidebar";
import SearchModal from "@/components/search-modal";
import { useState } from "react";

export default function ProductDetail() {
  const { id } = useParams();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { addToCart, isAddingToCart } = useCart();
  const { toast } = useToast();

  const { data: watch, isLoading, error } = useQuery<Watch>({
    queryKey: ["/api/watches", id],
  });

  const handleAddToCart = () => {
    if (watch) {
      addToCart({ watchId: watch.id, quantity: 1 });
      toast({
        title: "Added to cart",
        description: `${watch.name} has been added to your cart.`,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header onSearchClick={() => setIsSearchOpen(true)} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-48 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="h-96 bg-gray-200 rounded"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded w-3/4"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-12 bg-gray-200 rounded w-32"></div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !watch) {
    return (
      <div className="min-h-screen bg-white">
        <Header onSearchClick={() => setIsSearchOpen(true)} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Watch Not Found</h1>
            <p className="text-gray-600 mb-8">The watch you're looking for doesn't exist.</p>
            <Link href="/">
              <Button className="bg-luxury-gold text-rich-black hover:bg-yellow-500">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Collection
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header onSearchClick={() => setIsSearchOpen(true)} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-8">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Collection
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="relative">
            <img 
              src={watch.image} 
              alt={watch.name}
              className="w-full h-96 lg:h-full object-cover rounded-lg shadow-lg"
            />
            <div className="absolute top-4 left-4 flex gap-2">
              {watch.isNew && (
                <Badge className="bg-luxury-gold text-rich-black">NEW</Badge>
              )}
              {watch.isOnSale && (
                <Badge className="bg-red-600 text-white">SALE</Badge>
              )}
              {watch.isLimited && (
                <Badge className="bg-purple-600 text-white">LIMITED</Badge>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl lg:text-4xl font-playfair font-bold text-rich-black mb-2">
                {watch.name}
              </h1>
              <p className="text-xl text-gray-600">{watch.brand}</p>
              <p className="text-lg text-gray-500">{watch.collection}</p>
            </div>

            <div className="flex items-center space-x-4">
              {watch.originalPrice && (
                <span className="text-2xl text-gray-500 line-through">
                  ${parseFloat(watch.originalPrice).toLocaleString()}
                </span>
              )}
              <span className="text-3xl font-bold text-luxury-gold">
                ${parseFloat(watch.price).toLocaleString()}
              </span>
            </div>

            <p className="text-gray-700 leading-relaxed">{watch.description}</p>

            {/* Specifications */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Specifications</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {watch.movement && (
                    <div>
                      <span className="font-medium">Movement:</span>
                      <span className="ml-2 text-gray-600">{watch.movement}</span>
                    </div>
                  )}
                  {watch.caseMaterial && (
                    <div>
                      <span className="font-medium">Case Material:</span>
                      <span className="ml-2 text-gray-600">{watch.caseMaterial}</span>
                    </div>
                  )}
                  {watch.dialColor && (
                    <div>
                      <span className="font-medium">Dial Color:</span>
                      <span className="ml-2 text-gray-600">{watch.dialColor}</span>
                    </div>
                  )}
                  {watch.strapMaterial && (
                    <div>
                      <span className="font-medium">Strap Material:</span>
                      <span className="ml-2 text-gray-600">{watch.strapMaterial}</span>
                    </div>
                  )}
                  {watch.waterResistance && (
                    <div>
                      <span className="font-medium">Water Resistance:</span>
                      <span className="ml-2 text-gray-600">{watch.waterResistance}</span>
                    </div>
                  )}
                  {watch.caseSize && (
                    <div>
                      <span className="font-medium">Case Size:</span>
                      <span className="ml-2 text-gray-600">{watch.caseSize}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={handleAddToCart}
                disabled={isAddingToCart}
                className="flex-1 bg-luxury-gold text-rich-black hover:bg-yellow-500 py-3 text-lg font-semibold"
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                {isAddingToCart ? "Adding..." : "Add to Cart"}
              </Button>
              
              <div className="flex gap-2">
                <Button variant="outline" size="icon" className="border-luxury-gold text-luxury-gold hover:bg-luxury-gold hover:text-rich-black">
                  <Heart className="h-5 w-5" />
                </Button>
                <Button variant="outline" size="icon" className="border-luxury-gold text-luxury-gold hover:bg-luxury-gold hover:text-rich-black">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Additional Info */}
            <div className="text-sm text-gray-600 space-y-2">
              <p>✓ Authentic timepiece with certificate of authenticity</p>
              <p>✓ Free worldwide shipping on orders over $1,000</p>
              <p>✓ 30-day return policy</p>
              <p>✓ 2-year international warranty</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <CartSidebar />
    </div>
  );
}
